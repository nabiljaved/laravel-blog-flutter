import 'package:blog_app_laravel/respository/respository.dart';

class BlogPostService {

  Repository _repository;

  BlogPostService(){
    _repository = Repository();
  }

    getALlBlogPosts() async{
        return await _repository.httpGet('get-all-blog-posts');
    }
}