import 'dart:convert';

import 'package:blog_app_laravel/models/blog_post.dart';
import 'package:blog_app_laravel/services/blog_post_service.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:get_it/get_it.dart';
import 'blog_post_details_screen.dart';




class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  //create instance of blog post service
  //BlogPostService _blogPostService = new BlogPostService();
  BlogPostService get service => GetIt.I<BlogPostService>();

  @override
  void initState() {
    super.initState();

  }

  Future<List<BlogPost>>_getAllBlogPosts() async{
    //var result = await http.get('http://blog-api.lutforrahman.com/api/get-all-blog-posts');

    var result = await service.getALlBlogPosts();
    List<BlogPost> list = List<BlogPost>();
    if(result !=null){
      var posts = json.decode(result.body);
      print(result.body);

      posts.forEach((items){
        var model = BlogPost();
        model.title = items['title'];
        model.details = items['details'];
        model.featuredImageUrl = items['featured_image_url'];
        model.category  = items['category']['name'];
        model.createdAt = items['created_at'];
        list.add(model);
      });
    }
    return list;
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Blog App'),
      ),
      body: FutureBuilder<List<BlogPost>>(
          future: _getAllBlogPosts(),
          builder: (BuildContext context, AsyncSnapshot<List<BlogPost>> snapshot){
              if(snapshot.hasData){
                  return ListView.builder(
                    itemCount: snapshot.data.length,
                    itemBuilder: (context, index){
                      return Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Card(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Padding(
                                padding: const EdgeInsets.all(4.0),
                                child: Image.network(snapshot.data[index].featuredImageUrl),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(4.0),
                                child:
                                InkWell(
                                  onTap: (){
                                    Navigator.push(context, MaterialPageRoute(builder: (context) => BlogPostDetailsScreen(blogPost: snapshot.data[index],)));
                                  },
                                    child: Text(snapshot.data[index].title,
                                      textAlign: TextAlign.left,
                                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),)
                                ),
                              ),
                                 Row(
                                   children: <Widget>[
                                     Padding(
                                       padding: const EdgeInsets.all(6.0),
                                       child: Text(snapshot.data[index].category,
                                        style: TextStyle(
                                        backgroundColor: Colors.black12,
                                        fontSize: 16.0
                                ),
                                       textAlign: TextAlign.left,
                                       ),
                                     ),
                                     Padding(
                                       padding: const EdgeInsets.all(6.0),
                                       child: Text(DateFormat("dd-MMM-YYYY").format(DateTime.parse(snapshot.data[index].createdAt)), style: TextStyle(backgroundColor: Colors.black12, fontSize: 16.0),),
                                     )
                                   ],
                                 ),
                            ],
                          ),
                        ),
                      );
                    }
                  );
              }else{
                return Container(child: Text('Loading........'),);
              }
          },
      ),
    );
  }
}
