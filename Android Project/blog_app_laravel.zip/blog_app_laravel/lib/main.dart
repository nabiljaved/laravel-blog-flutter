import 'package:blog_app_laravel/services/blog_post_service.dart';
import 'package:blog_app_laravel/widgets/App.dart';
import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';

void setupLocator() {
  GetIt.I.registerLazySingleton(() => BlogPostService());
}

void main(){
  setupLocator();
  runApp(App());

}