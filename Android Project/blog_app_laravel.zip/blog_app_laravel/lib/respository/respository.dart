import 'package:http/http.dart' as http;

class Repository{

  String _baseUrl = "http://blog-api.lutforrahman.com/api";
  String _baseUrl2 = "http://192.168.0.104:5000/api";

    httpGet(String api) async{
      return await http.get(_baseUrl2+ "/"+ api);
    }

}