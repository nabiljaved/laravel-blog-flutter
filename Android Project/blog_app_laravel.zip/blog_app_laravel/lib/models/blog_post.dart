class BlogPost{

    int id;
    String title;
    String details;
    String featuredImageUrl;
    String category;
    String createdAt;

}